
var StaticSnippetView = new KONtx.Class({
	ClassName: 'StaticSnippetView',
	
	// Pay attention to the fact this one extends from AnchorSnippetView
	// That is because this snippet always exists in all profiles and 
	// isn't a "custom" one added per user action
	Extends: KONtx.system.AnchorSnippetView,
		
	createView: function() {
		/*
		this.controls.text = new KONtx.element.Text({
			label: "Artkick",
			styles: {
				fontSize: KONtx.utility.scale(20),
				vAlign: "center",
				hAlign: "center",
				color: "#FFFFFF"
			},
		}).appendTo(this);*/
		
	    this.logoContainer = new KONtx.element.Container({
        	styles:{
        		width:this.width,
        		height:this.height,
        		backgroundColor:"black"
        	}
        }).appendTo(this);
		
		this.logo = new KONtx.element.Image({
        	src:"Images/bk.jpg",
        	styles:{
        		hAlign: "center",
        		vAlign: "center",
                        height: 0.7*this.height,
                        width: 250*0.7*this.height/74
        	}
        }).appendTo(this.logoContainer);

        //this.logo.aspectSizeMin(this.height);
        //this.controls.background.fitToParent();
        /*
         this.capPanel = new KONtx.element.Text({
			label: "dimension "+this.width+", "+this.height,
			        styles: {
			          width: this.width,
			          height: this.height,
				      fontSize: KONtx.utility.scale(18),
				      hAlign: "center",
				      color: "#FFFFFF",
				      textAlign: "center",
                      zOrder: 999,
                      backgroundColor:"gray",
			        },
			        wrap:true
		}).appendTo(this); */
	},
});
