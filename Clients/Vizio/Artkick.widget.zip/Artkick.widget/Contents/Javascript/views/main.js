var MainView = new KONtx.Class({
	ClassName: 'MainView',
	
	Extends: KONtx.system.FullscreenView,
    
    
    _elementEvents:function(eventTypes){
    	this.parent(['keydown'].concat(eventTypes));

    },
    
    
    warnMsg: function(msg){
    	if(this.messagePanel){
    		this.messagePanel.setText(msg);
    		this.messagePanel.show();
    	}
    	
    },
    
    
    _dispatcher: function(event, payload){
    	    var currTime = getRealTime()*1000;
   	        if(currTime - $('view-Main').pollStamp > 32000){
   	        	$('view-Main').poll();
   	        }
    	    
    	    
    	
    	    if($('view-Main').messagePanel){
    			//$('view-Main').messagePanel.setText("KeyCode: "+event.keyCode);
    		}
    		
    		if(event.keyCode == 405){
    			
               	$('view-Main').goToReg();
    		} else if(event.keyCode == 404 & !$('view-Main').inReg){
    			
    			$('view-Main').capPanel.show();
    			$('view-Main').timer = KONtx.utility.timer.setTimeout(function(){
            		 $('view-Main').capPanel.visible = false;
                },5000);
    		} else if(event.keyCode == 39 || event.keyCode == 417){
    			
    			if(!$('view-Main').inReg){
    				this.nextImage(1);
    			}
    			
    			
    		} else if(event.keyCode == 37 || event.keyCode == 412){
    			
    			if(!$('view-Main').inReg){
    				this.nextImage(0);
    			}
    			
    			
    		}
    },
    
    checkRegStatus: function(tryTimes){
    	
    	if(tryTimes<=0){
    		//display message...
    		this.warnMsg("Unable to connect to Artkick Server, please try again later!");
    		return;
    	}
    	
    	var requestLink = this.regBase+"getRegStatus?deviceId="+this.deviceId+"&deviceMaker="+this.maker+"&regCode="+this.regCode;
    	var xmlHttp = new XMLHttpRequest();
    	
    	function errHandle(){
            xmlHttp.abort();
            $('view-Main').checkRegStatus(tryTimes-1);
            //alert("Request timed out");
        }
    	
    	
    	xmlHttp.onreadystatechange = function(){    		
           if (xmlHttp.readyState == 4 && xmlHttp.status == 200) {
               KONtx.utility.timer.clearTimeout(xmlHttpTimeout); 
               //alert(xmlHttp.responseText);
               try{
               	  var result = JSON.parse(xmlHttp.responseText);
               	  if(result["Status"]=="success"){
               	  	  $('view-Main').inReg = false;  
               	  	  
               	  	  if($('view-Main').regTimeout) {
               	  	  	KONtx.utility.timer.clearTimeout($('view-Main').regTimeout);
               	  	  }           	  	  
               	  	  
               	  	  
               	  	  $('view-Main').regScreen.hide();
               	  	  if($('view-Main').bigPanel.img){
               	  	  	$('view-Main').bigPanel.show();
               	  	  }
               	  	  $('view-Main').updateImage(20);
               	  	  
               	  }else{
               	  	
               	  	 $('view-Main').regPolling = KONtx.utility.timer.setTimeout(function(){
               	  	 	  $('view-Main').checkRegStatus(20);
               	  	 },500);
               	  }
               	  
               }catch(err){
               	  //parser error or server error
               	  errHandle();
               }
           }
    	}
    	
    	
    	

        var xmlHttpTimeout=KONtx.utility.timer.setTimeout(errHandle,8000);
        
    	xmlHttp.open("GET",requestLink,true);
    	xmlHttp.send();    	
    	
    	
    },
    
    getRegCode: function(tryTimes){
    	if(tryTimes<=0){
    		//display message...
    		this.warnMsg("Unable to connect to Artkick Server, please try again later!");
    		return;
    	}
    	
    	
    	var xmlHttp = new XMLHttpRequest();
    	
    	function errHandle(){
            xmlHttp.abort();
            $('view-Main').getRegCode(tryTimes-1);
            //alert("Request timed out");
        }
    	
    	
    	xmlHttp.onreadystatechange = function(){    		
           if (xmlHttp.readyState == 4 && xmlHttp.status == 200) {
               KONtx.utility.timer.clearTimeout(xmlHttpTimeout); 
               //alert(xmlHttp.responseText);
               try{
               	  var result = JSON.parse(xmlHttp.responseText);
               	  if(result["Status"]=="success"){
                      $('view-Main').regCode = result['RegCode'];
                      $('view-Main').regScreen.middlePanel.setText($('view-Main').regCode);
                      $('view-Main').regTimeout = KONtx.utility.timer.setTimeout(function(){
                      	   if(!$('view-Main').inReg){
                      	   	  return;
                      	   }
                      	   
                      	   $('view-Main').regScreen.middlePanel.setText("Your registration code is expired! Getting a new one...");
                      	   $('view-Main').getRegCode(20);
                      	   
                      	   
                      },900*1000);
               	  	  
               	  	 
               	  	 
               	  }else{
               	  	 errHandle();
               	  }
               }catch(err){
               	  //parser error or server error
               	  errHandle();
               }
           }
    	}
    	
    	
    	

        var xmlHttpTimeout=KONtx.utility.timer.setTimeout(errHandle,8000);
        
    	xmlHttp.open("GET",this.regCodeRequest,true);
    	xmlHttp.send();
    },
  
    initCapPanel: function(){
    	this.capPanel = new KONtx.element.Text({
			label: " ",
			        styles: {
			          width: 0.6*this.width,
			          height: 0.2*this.height,
				      fontSize: KONtx.utility.scale(18),
				      hAlign: "center",
				      vOffset: 0.8*this.height-10,
				      color: "#FFFFFF",
				      textAlign: "center",
                      zOrder: 999,
                      visible: false,
                      backgroundColor:"gray",
                      padding:5
			        },
			        wrap:true
		}).appendTo(this);  
    },

    initRegScreen: function(){
    	this.regScreen = new KONtx.element.Container({
    		styles:{
    			width: this.width,
    			height: this.height,
    		    backgroundColor:"#FFFFFF",
    		    zOrder:999,
    		    visible:false	 
    		}
    	}).appendTo(this);
    	
    	var topOffset = 10;
    	var imageHeight = 100;
    	
    	this.cornerPanel = new KONtx.element.Container({
    		styles:{
    			width:0.08*this.width,
    			height:0.08*this.width*0.31,
    			zOrder:999,
    			hOffset: 0.92*this.width-15,
    			vOffset: this.height-0.08*this.width*0.31-15,
    			visible:false
    		}
    	}).appendTo(this);
        this.cornerLogo = new KONtx.element.Image({
        	src:"Images/logo.png",
        	styles:{
        		hAlign: "center"
        	}
        }).appendTo(this.cornerPanel);
        this.cornerLogo.aspectSizeMin(0.08*this.width*0.31);
        
        this.bigPanel = new KONtx.element.Container({
        	styles:{
        		width:this.width,
        		height:this.height,
        		hOffset:0,
        		vOffset:0,
        	}
        }).appendTo(this);        
        
        
    /*    
        
        this.testPanel = new KONtx.element.Container({
        	styles:{
        		width:0.3*this.width,
        		height:0.3*this.height,
        		zOrder:999,
        		hOffset:0.35*this.width,
        		vOffset:0.35*this.height
        	}
        }).appendTo(this);

        this.testPanel.image = new KONtx.element.Image({
        	src:"Images/logo.png",
        	styles:{
        		hAlign: "center"
        	}
        }).appendTo(this.testPanel);
        this.testPanel.image.fitToParent();
       */ 
    	
    	this.regScreen.imagePanel = new KONtx.element.Container({
    		styles:{
    			width:this.width,
    			height:imageHeight,
    		    backgroundColor:"#FFFFFF",
    		    zOrder:999,
    		    vAlign:"top"	 
    		}
    	}).appendTo(this.regScreen);
    	
    	this.regScreen.titleImg = new KONtx.element.Image({
                src: "Images/ArtkickLogo.png", 
                styles:{
                    hAlign: "center",
                }

    	}).appendTo(this.regScreen.imagePanel);
    	
    	this.regScreen.titleImg.aspectSizeMin(imageHeight);
    	
    	var upperText = "Please connect your Yahoo Smart TV to your account\n\n";
    	upperText += "Artkick connects this TV to an IOS or Android phone or tablet.\n\n";
    	upperText += "Install Artkick from the the App Store or Google Play.\n\n";
    	upperText += "Tap Menu/Connect TV\n\n";
    	upperText += "and enter this code to activate:";
    	this.regScreen.upperPanel = new KONtx.element.Text({
			     label: upperText,
			        styles: {
				      fontSize: KONtx.utility.scale(22),
				      hAlign: "center",	
				      vAlign: "top",	
				      vOffset: topOffset+imageHeight,		      
				      color: "black",
				      textAlign: "center",
                      zOrder: 999,
			        }
		         }).appendTo(this.regScreen);
		 
		 var upperPanelHeight = this.regScreen.upperPanel.height;
		 this.regScreen.middlePanel = new KONtx.element.Text({
			     label: " ",
			        styles: {
				      fontSize: KONtx.utility.scale(28),
				      hAlign: "center",
	                  vOffset: topOffset+imageHeight+20+upperPanelHeight,	
				      color: "blue",
				      textAlign: "center",
                      zOrder: 999,
			        }
		         }).appendTo(this.regScreen);
  
        var middlePanelHeight =  this.regScreen.middlePanel.height;
    	this.regScreen.lowerPanel = new KONtx.element.Text({
			     label: "\nThis screen will automatically update as soon as your activation completes",
			        styles: {
				      fontSize: KONtx.utility.scale(22),
				      hAlign: "center",
				      vOffset: topOffset+imageHeight+20+upperPanelHeight+middlePanelHeight,
				      color: "black",
				      textAlign: "center",
                      zOrder: 999,
			        }
		         }).appendTo(this.regScreen);  
    	
    },    
    
    
    nextImage: function(forward){
    	
        var currTime = getRealTime()*1000;
   	    if(currTime - $('view-Main').pollStamp > 32000){
   	       $('view-Main').poll();
   	    }
    	
    	
        if(this.inReg){
    		return;
    	}
    	
    	
    	var url = new URL();
    	url.location = this.nextRequest+"&next="+forward;
    	url.fetchAsync(url_done);
    	
    	function url_done(url){
    		try{
               	var result = JSON.parse(url.responseData);
               	if(result["Status"]!="Failure"){
               	   $('view-Main').stretch = result['stretch'];
               	   $('view-Main').displayImage(result);               	  	 
               	  	 
               	}else{
               	  	 
               	   $('view-Main').goToReg();
               	}            	  
               	  
            }catch(err){
               	//parser error or server error
               	log("error!");
            }
    		
    	}    	
    	    	
    },
    
    nextImageOld: function(forward, tryTimes){
        if(this.inReg){
    		return;
    	}
    	
    	
    	if(tryTimes<=0){
    		//display message...
    		this.warnMsg("Unable to connect to Artkick Server, please try again later!");
    		return;
    	}
    	

    	
    	var xmlHttp = new XMLHttpRequest();
    	
    	function errHandle(){
            xmlHttp.abort();
            $('view-Main').nextImage(forward,tryTimes-1);
            //alert("Request timed out");
        }
    	
    	
    	xmlHttp.onreadystatechange = function(){
    	   if($('view-Main').inReg){
    	   	   return;
    	   }
    		
           if (xmlHttp.readyState == 4 && xmlHttp.status == 200) {
               KONtx.utility.timer.clearTimeout(xmlHttpTimeout); 
               //alert(xmlHttp.responseText);
               try{
               	  var result = JSON.parse(xmlHttp.responseText);
               	  if(result["Status"]!="Failure"){
               	  	 $('view-Main').stretch = result['stretch'];
               	  	 $('view-Main').displayImage(result);               	  	 
               	  	 
               	  }else{
               	  	 
               	  	 $('view-Main').goToReg();
               	  }
               }catch(err){
               	  //parser error or server error
               	  errHandle();
               }
           }
    	}
    	
    	
    	

        var xmlHttpTimeout=KONtx.utility.timer.setTimeout(errHandle,8000);
    	xmlHttp.open("GET",this.nextRequest+"&next="+forward,true);
    	xmlHttp.send();    	
    	
    },
    
                
    updateImage: function(tryTimes){
    	if(this.inReg){
    		return;
    	}
    	
    	
    	if(tryTimes<=0){
    		//display message...
    		this.warnMsg("Unable to connect to Artkick Server, please try again later!");
    		return;
    		
    	}
    	
    	this.cornerPanel.show();
    	var xmlHttp = new XMLHttpRequest();
    	
    	function errHandle(){
            xmlHttp.abort();
            $('view-Main').updateImage(tryTimes-1);
            //alert("Request timed out");
        }
    	
    	
    	xmlHttp.onreadystatechange = function(){
    	   if($('view-Main').inReg){
    	   	   return;
    	   }
    		
           if (xmlHttp.readyState == 4 && xmlHttp.status == 200) {
               KONtx.utility.timer.clearTimeout(xmlHttpTimeout); 
               //alert(xmlHttp.responseText);
               try{
               	  var result = JSON.parse(xmlHttp.responseText);
               	  if(result["Status"]!="Failure"){
               	  	 $('view-Main').displayImage(result);               	  	 
               	  	 $('view-Main').handleAuto(result);
               	  }else{
               	  	 
               	  	 $('view-Main').goToReg();
               	  }
               }catch(err){
               	  //parser error or server error
               	  errHandle();
               }
           }
    	}
    	
    	
    	

        var xmlHttpTimeout=KONtx.utility.timer.setTimeout(errHandle,8000);
    	xmlHttp.open("GET",this.imageRequest,true);
    	xmlHttp.send();
    },
       
    goToReg: function(){
    	if($('view-Main').buffImg){
    		$('view-Main').bigPanel.removeChild($('view-Main').buffImg);
    		$('view-Main').buffImg = null;
    	}
    	
    	
    	
    	//this.messagePanel.hide();
    	this.cornerPanel.hide();
    	this.capPanel.hide();
    	this.inReg = true;
    	
    	if(this.bigPanel){
    	   this.bigPanel.hide();
    	}
    	
    	this.regScreen.show();
    	this.getRegCode(20);
    },  
    
    
    fitScreen: function(){
    	var imageElem =$('view-Main').bigPanel.img;
    	var screenRatio = $('view-Main').height/$('view-Main').width;
    	var imageRatio = imageElem.srcHeight/imageElem.srcWidth;
    	
    	if(imageRatio>1){
    		imageElem.fitToParent();
    		return;
    	}
    	
    	if(screenRatio > imageRatio){
    		imageElem.aspectSizeMax($('view-Main').width);
    	}else{
    		//imageElem.aspectSizeMin($('view-Main').height);
    		imageElem.aspectSizeMax(imageElem.srcWidth*($('view-Main').height/imageElem.srcHeight));
    	}
    },
    
    
    refreshImage: function(){
    	    if($('view-Main').currImageUrl==""){
    	    	return;
    	    }
    	
    	
    	    if($('view-Main').displaying){
    	    	return;
    	    }
    	    
    	    
            this.newImg = new KONtx.element.Image({
                src: $('view-Main').currImageUrl, 
                styles:{
                    vAlign: "center",
                    hAlign: "center",
                },
                events:{
            	    onLoaded: function(event){
            	     if($('view-Main').displaying){
            	     	return;
            	     }	
            	    	
            	    	
                     if(this.src != $('view-Main').currImageUrl){
                     	return;
                     }
                     
            	     
            	     if($('view-Main').newImg){
            	     	$('view-Main').newImg.appendTo($('view-Main').bigPanel);
            	     }
            	    	
            	    	           //remove previous image
                      if($('view-Main').buffImg){
            	         $('view-Main').bigPanel.removeChild($('view-Main').buffImg);
                      }	
                      
                      $('view-Main').buffImg = $('view-Main').newImg;
                      $('view-Main').newImg = null;
                      $('view-Main').bigPanel.img = $('view-Main').buffImg;
                      
                                   //set stretch again, becasue this DOM only support runtime CSS, and won't sustain its style. 
                                          
            if($('view-Main').stretch=='true'){
         	   $('view-Main').bigPanel.img.fillParent();
            }else{
               $('view-Main').fitScreen();
            }
            	          	               	          	
            	        	 	
            	    }
            	        	 

                }
            });    	
    },
    
    
        
    displayImage: function(result){
    	
        
         if(this.currImageUrl == result["imageURL"]){
         	 //set stretch
             if(this.bigPanel.img!=null){
         	   if(result['stretch']=='true'){
         	      this.bigPanel.img.fillParent();
               }else{
                  this.fitScreen();
         	   
               }
            }
         }
         

         

         
         //if image has changed
         else{
         	this.capPanel.visible = false;
            this.currImageUrl = result["imageURL"];
            	
            //clear timeout
            if(this.timer){
               KONtx.utility.timer.clearTimeout(this.timer);
            }
            
           
            this.warnMsg("Loading...");
                	
            	            
            this.caption = decodeURI(result["title"]+"\n"+ result["caption"]);	

            this.displaying = true; 
            this.newImg = new KONtx.element.Image({
                src: result['imageURL'], 
                styles:{
                    vAlign: "center",
                    hAlign: "center",
                },
                events:{
            	    onLoaded: function(event){
            	    	
                     if(this.src != $('view-Main').currImageUrl){
                     	return;
                     }
                     
            	     
            	     if($('view-Main').newImg){
            	     	$('view-Main').newImg.appendTo($('view-Main').bigPanel);
            	     	//$('view-Main').testPanel.image.src = this.src;
            	     	//$('view-Main').testPanel.image.fitToParent();
            	     	
            	     }
            	    
            	      $('view-Main').messagePanel.hide();
            	      //remove previous image
                      if($('view-Main').buffImg){
            	         $('view-Main').bigPanel.removeChild($('view-Main').buffImg);
                      }	
                      
                      $('view-Main').buffImg = $('view-Main').newImg;
                      $('view-Main').newImg = null;
                      $('view-Main').bigPanel.img = $('view-Main').buffImg;
                      
                      $('view-Main').displaying = false;
                      
                                   //set stretch again, becasue this DOM only support runtime CSS, and won't sustain its style. 
                                          
            if(result['stretch']=='true'){
         	   $('view-Main').bigPanel.img.fillParent();
            }else{
               $('view-Main').fitScreen();
            }
            	          	   
            	       //display caption
            	       $('view-Main').capPanel.setText($('view-Main').caption);
            	       $('view-Main').capPanel.visible = true;
 
              	       $('view-Main').timer = KONtx.utility.timer.setTimeout(function(){
            		       $('view-Main').capPanel.visible = false;
            		   },5000);
            	          	
            	        	 	
            	    }
            	        	 

                }
            });
            
              
              

         } 
    },
           
    _handleStateChange: function(newstate){
    	KONtx.HostEventManager.send('setScreensaver', false);
    },
        
	createView: function() {
		KONtx.HostEventManager.send('setScreensaver', false);
		this.currImageUrl = "";
		this.inReg = false; 
		this.stretch = "false";
		this.displaying = false;
		    
	    //API variables
		this.imageBase = "http://sleepy-scrubland-3038.herokuapp.com/client/v1.1/currentImage.json?";
  	    this.nextImageBase = "http://sleepy-scrubland-3038.herokuapp.com/client/v1.1/nextImage.json?";
  	    this.regBase = "http://evening-garden-3648.herokuapp.com/registration/v1.0/";
  	    this.pollBase = "http://shrouded-chamber-7349.herokuapp.com/poll?";
  	    this.pollInterval = 500;
  	    
  	    this.deviceId = tv.system.deviceId;
  	    this.maker = "Yahoo";
  	    this.regCode = " ";   
  	    this.imageRequest = this.imageBase+"deviceId="+this.deviceId+"&deviceMaker="+this.maker;
  	    this.nextRequest = this.nextImageBase+"deviceId="+this.deviceId+"&deviceMaker="+this.maker;
		this.regCodeRequest = this.regBase+"getRegCode?deviceId="+this.deviceId+"&deviceMaker="+this.maker;
		this.pollRequest = this.pollBase+"user="+this.maker+this.deviceId;
		this.pollStamp = getRealTime()*1000;
		
		this.autoRunning = null;
		this.morningChecker = null;
		this.lastSignDay = -1;
		
        this.messagePanel = new KONtx.element.Text({
			label: "Hello World!",
			styles: {
				fontSize: KONtx.utility.scale(24),
				vAlign: "center",
				hAlign: "center",
				color: "white",
				testAlign: "center",
                visible: false,
                zOrder: 999,
			},
		}).appendTo(this);
		
		this.initCapPanel();
		this.initRegScreen(); 
        this.updateImage(20);
        this.poll();
        KONtx.utility.timer.setInterval(function(){
           $('view-Main').checkPoll();
        },5000); 
       
    },
   
   checkPoll: function(){
   	  var currTime = getRealTime()*1000;
   	  log("checking...");
   	  if(currTime - $('view-Main').pollStamp > 32000){   	  	  
   	  	  $('view-Main').poll();
   	  }else{
   	  	log("polling is normal!");
   	  }
   }, 
  
 
   poll: function(){    	
    	this.cornerPanel.show();    	
    	var url = new URL();
    	url.location = this.pollRequest;
    	url.fetchAsync(url_done);
    	
    	function url_done(url){
    		$('view-Main').pollStamp = getRealTime()*1000;
  	 		KONtx.utility.timer.setTimeout(function(){
            	   $('view-Main').poll();
            },2);
            
            
             
    		print("fetch complete");
    		print(url.response);	
    		try{
               	var result = JSON.parse(url.responseData);
 	 			if(result['type']==null){
  	 				//console.log("Returned! Timeout, do nothing!");
  	 			}
  	 			else if(result['type']=='image'){
  	 			  //console.log("Returned! New image!");
  	 			  $('view-Main').displayImage(result);
  	 			}
  	 			
  	 			else if(result['type']=='removePlayer'){
  	 			  
  	 			  if($('view-Main').autoRunning != null ){
  		             KONtx.utility.timer.clearInterval($('view-Main').autoRunning);
  	              }
  	 
  	              if($('view-Main').morningChecker != null){ 
  	 	             KONtx.utility.timer.clearInterval($('view-Main').morningChecker);
  	              }
  	              
  	              $('view-Main').goToReg();
  	              
  	 			}
  	 			
  	 			else if(result['type']=='regPlayer'){
  	 				$('view-Main').inReg = false;  
               	  	  
               	  	if($('view-Main').regTimeout) {
               	  	  KONtx.utility.timer.clearTimeout($('view-Main').regTimeout);
               	  	}           	  	                	  	  
               	  	  
               	  	$('view-Main').regScreen.hide();
               	  	$('view-Main').bigPanel.show();
               	  	$('view-Main').updateImage(20);
  	 			}
  	 			
  	 			else if(result['type']=='autoPlay'){
                    $('view-Main').handleAuto(result);
  	 			}  
  	 			  
            	  
               	  
            }catch(err){
               	//parser error or server error
               	log("error!");
            }
    		
    	}
    	
    
    },
    
  handleAuto: function(result){
  	 if($('view-Main').autoRunning != null){
  		KONtx.utility.timer.clearInterval($('view-Main').autoRunning);
  	 }
  	 
  	 if($('view-Main').morningChecker != null){ 
  	 	KONtx.utility.timer.clearInterval($('view-Main').morningChecker);
  	 }
  	 
  	 if(result['autoInterval'] == 0){
  	 	$('view-Main').autoInterval = 0;
  	 	
  	 }else if(result['autoInterval'] > 0){
  	 	$('view-Main').autoInterval = result['autoInterval'];
  	 	//$('view-Main').nextImage(1);
  	 	$('view-Main').autoRunning = KONtx.utility.timer.setInterval(function(){
  	 		$('view-Main').nextImage(1);
  	 	},$('view-Main').autoInterval);
  	 	
  	 }else if(result['autoInterval'] == -1){
  	 	$('view-Main').autoInterval = -1;
  	 	$('view-Main').morningChecker = KONtx.utility.timer.setInterval(function(){
  	 	  var date = new Date();
  	 	  var day = date.getDay();
  	 	  var hour = date.getHours();
  	 	
  	 	  if(day!=$('view-Main').lastSignDay && hour== 3){
  	 		  $('view-Main').nextImage(1);
  	 		  $('view-Main').lastSignDay = day;
  	 	  }
  	 	},30*60*1000);
  	 }
  	 
  	 
  	 
  	 
  	 
  }    
 
 
 
  
  
/*    
   poll: function(){    	
    	this.cornerPanel.show();
    	var xmlHttp = new XMLHttpRequest();
    	
    	function errHandle(){
    		log("error handled...");
            xmlHttp.abort();
            xmlHttp = null;
  	 	    xmlHttpTimeout = null;
            KONtx.utility.timer.setTimeout(function(){
            	$('view-Main').poll();
            },2);
            
        }
    	
    	
    	xmlHttp.onreadystatechange = function(){


           //log("status changed "+xmlHttp.status); 
                  

           if (xmlHttp.readyState == 4 && xmlHttp.status == 200) {
               KONtx.utility.timer.clearTimeout(xmlHttpTimeout); 
               

               
               //alert(xmlHttp.responseText);
               try{
               	  var result = JSON.parse(xmlHttp.responseText);
 	 			  if(result['type']==null){
  	 				//console.log("Returned! Timeout, do nothing!");
  	 			  }
  	 			  else if(result['type']=='image'){
  	 				//console.log("Returned! New image!");
  	 				$('view-Main').displayImage(result);
  	 			  }
  	 			
  	 			  else if(result['type']=='removePlayer'){
  	 			  	$('view-Main').goToReg();
  	 			  }
  	 			
  	 			  else if(result['type']=='regPlayer'){
  	 				$('view-Main').inReg = false;  
               	  	  
               	  	if($('view-Main').regTimeout) {
               	  	  KONtx.utility.timer.clearTimeout($('view-Main').regTimeout);
               	  	}           	  	                	  	  
               	  	  
               	  	$('view-Main').regScreen.hide();
               	  	$('view-Main').bigPanel.show();
               	  	$('view-Main').updateImage(20);
  	 			  }
  	 			
  	 			  else if(result['type']=='autoPlay'){

  	 			  }  
  	 			  
  	 			  $('view-Main').pollStamp = getRealTime()*1000;
  	 			  KONtx.utility.timer.setTimeout(function(){
            	    $('view-Main').poll();
                  },2); 
                  
                    	 			  
  	 			  xmlHttp = null;
  	 			  xmlHttpTimeout = null;

  	 			             	  
               	  
               }catch(err){
               	  //parser error or server error
               	  log("error!");
               	  //errHandle();
               }
           }else{
           	  //log("poll has a problem");
           }
           
           
           
    	}
    	
    	
    	

        var xmlHttpTimeout=KONtx.utility.timer.setTimeout(errHandle,29000);
    	xmlHttp.open("GET",this.pollRequest,true);
    	xmlHttp.send();
    }    
    
*/   
    
});    

 

