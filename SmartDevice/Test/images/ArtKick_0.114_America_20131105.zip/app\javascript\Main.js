var widgetAPI = new Common.API.Widget();
var tvKey = new Common.API.TVKeyValue();
var pluginAPI = new Common.API.Plugin();
var ImageViewer = null;
var baseUrl = "http://sleepy-scrubland-3038.herokuapp.com/client/v1.0";
var baseImageUrl = baseUrl + "/currentImage.json";
var baseRegistrationUrl = "http://evening-garden-3648.herokuapp.com/registration/v1.0";
var deviceMaker = "Samsung";
var deviceId = null;
var registrationToken = null;
var regCode = null;
var regTimeout = null;
var displayImage = null;
var imagePollTimeInterval = 500; // 5 seconds
var duration = 0;	
var retryInterval;
var retryDuration;
var advancePending = false;

var Main =
{
};

Main.onLoad = function()
{
	alert('Main : onLoad()');
	alert($('body').width());
	alert($('body').height());
	ImageViewer = new CImageViewer('Common ImageViewer');
		
	widgetAPI.sendReadyEvent();
	
	//disable the screen saver
	pluginAPI.setOffScreenSaver();
	
	// Enable key event processing
	this.enableKeys();
	
	//body_sizer();
	
	deviceId = getDeviceId();
	registrationToken = getRegistrationToken();
	if(registrationToken == null || registrationToken == "")
		register();
	else
		showInitialImage();
};

function showInitialImage()
{
	//setupImageViewerEvents();
	$('div#screen').show();
	displayImage = getCurrentImage();
	//playImage(displayImage.url);
	if (displayImage == null)
		info("Image was not retrieved properly");
	else 
		playImage2(displayImage);
	
	//set up next pull
	if(displayImage != null && displayImage.nextPollInterval != null)
		imagePollTimeInterval = displayImage.nextPollInterval;
    alert("nextPull: "+ imagePollTimeInterval);
	setTimeout(checkImageChanges, imagePollTimeInterval);
}

function register()
{
	alert("Attempting registration");
	//show...will show "retrieving code..." or similar
	$('#regCode').css('background-color', '#FFFF80');
	$('#regCode').html("retrieving code...");
	
	$('#registration').show();
	
 	var regDetails = getRegCode();
	duration = 0;	
	retryInterval = regDetails.retryInterval;
	retryDuration = regDetails.retryDuration;
	regCode = regDetails.regCode;
	
	alert("register | retryInterval: " + retryInterval);
	alert("register | retryDuration: " + retryDuration);
	
	//document.getElementById('regCode').innerHTML =  regCode;
	$('#regCode').html(regCode);
	$('#regCode').css('background-color', '#80FF80');
	$('#autoUpdateText').show();
	$('#timedOutText').hide();
	$('#btnRetry').hide();
	$('#btnNewCode').removeClass('ui-state-active');
	$('#btnBack').addClass('ui-state-active');
	
	setTimeout(function() {checkRegistration();}, 500);
};

function checkRegistration()
{
	if (checkRegistrationStatus() == true)
	{
		$('#registration').hide();
		showInitialImage();
	}
	else if (duration <  retryDuration)
	{
		duration = duration + retryInterval;
		alert("Attempting registration again. Duration: " + duration);
		setTimeout(function() {checkRegistration();}, retryInterval);
	}
	else
	{
		alert("FAILED to register in time limit!  Duration: " + duration);
		$('#regCode').css('background-color', '#FF8080');
		$('#regCode').html('Time Expired');
		$('#autoUpdateText').hide();
		$('#timedOutText').show();
		$('#btnRetry').show();
		$('#btnBack').removeClass('ui-state-active');
		$('#btnRetry').addClass('ui-state-active');
	}
};

function getRegCode()
{
	alert("!!!!!!!!getRegCode: " + deviceMaker + deviceId);
	var urlGetRegCode   = baseRegistrationUrl + "/getRegCode";
		
	var xhReq = new XMLHttpRequest();
	xhReq.open("GET", urlGetRegCode + "?deviceId=" + deviceId + "&deviceMaker=" + deviceMaker, false);
	xhReq.send(null);
	if(xhReq.status != 200)
	 {
		 alert("Error receiving current image.");
		 return null;
	 }
	 
	 var regCodeJson = JSON.parse(xhReq.responseText);
	 alert("getRegCode | response: " + regCodeJson);
	 alert ("regCode: " + regCodeJson.RegCode);
	 alert("retryInterval: " + regCodeJson.RetryInterval);
	 alert("retryDuration: " + regCodeJson.RetryDuration);
	 return new RegistrationDetails(regCodeJson.RegCode, regCodeJson.RetryInterval * 1000, regCodeJson.RetryDuration * 1000);
	  //will reduce duration for now while debugging
	 //alert("retryDuration: " + "30");
	 //return new RegistrationDetails(regCodeJson.RegCode, regCodeJson.RetryInterval * 1000, 30 * 1000);
};

function checkRegistrationStatus()
{
	var urlGetRegCode   = baseRegistrationUrl + "/getRegStatus";
		
	var xhReq = new XMLHttpRequest();
	xhReq.open("GET", urlGetRegCode + "?deviceId=" + deviceId + "&deviceMaker=" + deviceMaker + "&regCode=" + regCode, false);
	xhReq.send(null);
	if(xhReq.status != 200)
	 {
		 alert("Error receiving current image.");
		 return false;
	 }
	 
	 var regStatusJson = JSON.parse(xhReq.responseText);
	 alert("checkRegistrationStatus | response: " + regStatusJson);
	 alert ("Status: " + regStatusJson.Status);
	 alert("RegToken: " + regStatusJson.RegToken);
	 		
	if (regStatusJson.Status != "success")
		return false;
				          
	registrationToken = regStatusJson.RegToken;
	
	if (registrationToken == "" || registrationToken == 'invalid')	
		return false;
	
	alert("Obtained registration token: " + registrationToken);
	saveRegistrationToken(registrationToken);
	
	return true;
		    
};

function getRegistrationToken()
{
	
	var regToken = sf.core.localData("RegistrationToken");
	alert(regToken);
	return regToken;
	//return null;
	//Kevin's Roku...
	//return "6bfac01b0d740363708d0d451cb0e2bf";
};

function saveRegistrationToken(regToken)
{
	sf.core.localData("RegistrationToken", regToken);
	alert("saved registration token");
};

function RegistrationDetails(regCode, retryInterval, retryDuration) {
	  this.regCode = regCode;
	  this.retryInterval = retryInterval;
	  this.retryDuration = retryDuration;
};

function getDeviceId()
{
	var networkPlugin=document.getElementById("networkPlugin");
	var MAC = networkPlugin.GetMAC(1);
	alert("MAC: " + MAC);
	return NNaviPlugin.GetDUID(MAC);
};

function getCurrentImage()
{
	var xhReq = new XMLHttpRequest();
	xhReq.open("GET", baseImageUrl + "?deviceId=" + deviceId + "&deviceMaker=" + deviceMaker + "&regToken=" + registrationToken, false);
	//xhReq.open("GET", baseImageUrl + "?deviceId=" + "1GH314049254" + "&deviceMaker=" + "Roku" + "&regToken=" + registrationToken, false);
	//xhReq.open("GET", "http://sleepy-scrubland-3038.herokuapp.com/client/checkin.json?snumber=56677test", false);
	xhReq.send(null);
	if(xhReq.status != 200)
		 {
		 alert("Error receiving current image.");
		 return null;
		 }
	 
	 var imageJson = JSON.parse(xhReq.responseText);
     
     alert ("URL: " + imageJson.imageURL);
     alert("title: " + imageJson.title);
     alert("Caption: " + imageJson.caption);
     alert("nextPull: " + imageJson.nextPull);
     alert("stretch: " + imageJson.stretch);
     return new Image(imageJson.imageURL + "?" + imageJson.stretch , imageJson.title, imageJson.caption,  imageJson.nextPull, imageJson.stretch);
};

function playImage(url)
{
	alert('playImage');
	alert('playImage url: ' + url);
	//clear any information message
	if(!isImageUrlValid(url))
	{
		info("Image Url " + url + " is not valid");
		setInterval(checkImageChanges, imagePollTimeInterval);
		return;
	}
	
	ImageViewer.play(url, 1920, 1080);
	
};

function playImage2(image)
{
	alert('playImage via Background image method');
	alert('playImage url: ' + image.url);
	//clear any information message
	info(null);
	imageInfo(null);
	
	if(!isImageUrlValid(image.url))
	{
		info("Image Url " + image.url + " is not valid");
		return;
	}
	
	//set and show the div containing the image
	$('div#screen').css('background-image', 'url('+image.url+')');
	if(image.stretch=='true')
		$('div#screen').css('background-size','cover');
    else
    	$('div#screen').css('background-size','contain');
    $('div#screen').show();
  
    //show the info when replacing image
    showImageInfo(image, false);
    
    displayImage = image;
    
    advancePending = false;
    $('#advancingImageNotice').hide();
};

function isImageUrlValid(url)
{
	var xhReq = new XMLHttpRequest();
	xhReq.open("GET", url, false);
	xhReq.send(null);
	alert ("Status code: " + xhReq.status);
	if(xhReq.status != 200)
		{
		alert("Image Url is not valid.");
		return false;
		}
	return true;
};

function checkImageChanges()
{
	alert('checkImageChanges');
	var image = getCurrentImage();
       
	alert ("displayImage.url: " + displayImage.url);
	if (image == null)
		info("Image was not retrieved properly");
	else if (displayImage.url != image.url)
		playImage2(image);
	//reset variables
	//info(null);
	//imageInfo (null);
	//displayImage = image;
	
	
	//ImageViewer.prepareNext(displayImage.url, ImageViewer.Effect.FADE1);
	
	//set up next pull
	if(image != null && image.nextPollInterval != null)
		imagePollTimeInterval = image.nextPollInterval;
    alert("nextPull: "+ imagePollTimeInterval);
	setTimeout(checkImageChanges, imagePollTimeInterval);
};

function Image(url, title, caption, nextPollInterval, stretch) {
	  this.url = url;
	  this.title = title;
	  this.caption = caption;
	  this.nextPollInterval = nextPollInterval;
	  this.stretch = stretch;
	};
	
function setupImageViewerEvents()
{
	alert('setupEvents');
	//ImageViewer.startSlideshow();
	ImageViewer.setFrameArea(0, 0, 960, 540);
	//ImageViewer.setOnBufferingComplete(function(){
	//	alert('Buffering Complete)');
	//	ImageViewer.showNow();
	//});
	//ImageViewer.setOnRenderingComplete(function(){
	//	alert('Rendering Complete');
	//	setInterval(checkImageChanges, imagePollTimeInterval);
	//});
	//ImageViewer.stop();
	
	ImageViewer.show();
}

function advanceImage(next)
{
	var xhReq = new XMLHttpRequest();
	xhReq.open("GET", baseUrl + "/nextImage" + "?deviceId=" + deviceId +
			   "&deviceMaker=" + deviceMaker + "&regToken=" + registrationToken + 
			   "&next=" + next
			   , false);
	xhReq.send(null);
	if(xhReq.status != 200)
    {
		alert("Error advancing image.");
		return null;
    }
};

function info (message) {
	if(message == null)
		{
		$('#imageTitle').html("");
		alert ("setting to null");
		$('#information').hide();
		}
	else
		{
		$('#imageTitle').html(message);
		$('#information').show();
		}
}

function imageInfo (message) {
	if(message == null)
		{
		$('#imageCaption').html("");
		alert ("setting to null");
		$('#information').hide();
		}
	else
		{
		$('#imageCaption').html(message);
		$('#information').show();
		}
}

function showImageInfo(image, doAnimate)
{
	if ($('div#information').is(":visible") == true)
		return;
	
	$('div#information').css("top", $('div#screen').height() + "px");
	
	info(image.title);
	imageInfo(image.caption);
	
	var finalTop = $('div#screen').height() - $('div#information').height();
	
	if (doAnimate == true)
	{
		$('div#information').css("top", $('div#screen').height + "px");
		//-=50
		var infoHeight = $('div#information').height();
		$( "#information" ).animate({
		    top: finalTop + "px"
		  }, 400, function() {
		    // Animation complete.
		});
	}
	else
		$('div#information').css("top", finalTop + "px");

    setTimeout(function(){ clearImageInfo(image); }, 4000);
};

function clearImageInfo(image)
{
	if (image.url == displayImage.url)
	{
		alert('clearing info');
		var finalTop = $('div#screen').height();
		$( "#information" ).animate({
		    top: finalTop + "px"
		  }, 400, function() {
			  //animate complete
			  info(null);
			  imageInfo(null);
		  });
		//info(null);
		//imageInfo(null);
	}
	else
		alert('not clearing info as image was changed before timeout');
}

function body_sizer() {  
	  var bodywidth = $(window).width();
	  var bodyheight = $(window).height();
	  alert("body size: " + bodywidth + "x" + bodyheight);
	  $("#registration").width(bodywidth - 4);
	  $("#registration").height(bodyheight - 4);
}

function devTestBypassReg()
{
	$('#registration').hide();
	deviceId= "1GH314049254";
	deviceMaker = "Roku";
	registrationToken = "6bfac01b0d740363708d0d451cb0e2bf";
	showInitialImage();
}

Main.onUnload = function()
{
	ImageViewer.destroy();
};

Main.enableKeys = function()
{
	document.getElementById("anchor").focus();
};

Main.keyDown = function()
{
	var keyCode = event.keyCode;
	var activeButton = null;
	var nextButton = null;
	alert("Key pressed: " + keyCode);

	switch(keyCode)
	{
		case tvKey.KEY_RETURN:
		case tvKey.KEY_PANEL_RETURN:
			alert("RETURN");
			break;
		case tvKey.KEY_LEFT:
			alert("LEFT");
			if ($('div#screen').is(":visible") == true)
			{
				advancePending = true;
				$('#advancingImageNotice').show();
				advanceImage("0");
			}
			break;
		case tvKey.KEY_RIGHT:
			alert("RIGHT");
			if ($('div#screen').is(":visible") == true)
			{
				advancePending = true;
				$('#advancingImageNotice').show();
				advanceImage("1");
			}
			break;
		case tvKey.KEY_UP:
			alert("UP");
			activeButton = $('button.ui-state-active');
			nextButton = activeButton.parent().parent().prev().find('button:visible');
			alert(nextButton.text());
			if (nextButton.length > 0)
			{
				activeButton.removeClass('ui-state-active');
				nextButton.addClass('ui-state-active');
			}
			//works only for two buttons
			//$('#btnNewCode').addClass('ui-state-active');
			//$('#btnBack').removeClass('ui-state-active');
			break;
		case tvKey.KEY_DOWN:
			alert("DOWN");
			//works only for two buttons
			activeButton = $('button.ui-state-active');
			nextButton = activeButton.parent().parent().next().find('button:visible');
			alert(nextButton.text());
			if (nextButton.length > 0)
			{
				activeButton.removeClass('ui-state-active');
				nextButton.addClass('ui-state-active');
			}
			//$('#btnNewCode').removeClass('ui-state-active');
			//$('#btnBack').addClass('ui-state-active');
			break;
		case tvKey.KEY_INFO:
			alert("INFO");
			alert("displayImage.caption: " + displayImage.caption);
			//imageInfo (displayImage.title + " " + displayImage.caption);
			//info(displayImage.title);
			//imageInfo(displayImage.caption);
			//setTimeout(function() {imageInfo (null);}, 10000);
			if ($('div#screen').is(":visible") == true)
				showImageInfo(displayImage, true);
			break;
		case tvKey.KEY_ENTER:
		case tvKey.KEY_PANEL_ENTER:
			alert("ENTER");
			$('button.ui-state-active').click();
			break;
		case tvKey.KEY_TOOLS:
			alert("TOOLS");	
			break;
		case tvKey.KEY_RED:
			alert("RED key - clearing registration token.");
			saveRegistrationToken("");
			break;
		case tvKey.KEY_GREEN:
			alert("GREEN key - bypassing registration to use test reg");
			devTestBypassReg();
			break;
		default:
			alert("Unhandled key");
			break;
	}
};
